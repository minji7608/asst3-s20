#ifndef CYCLETIMER_H
/* Cycle timer code, adapted from CycleTimer.h found in 15-418 code repositories */

double currentSeconds();
#define CYCLETIMER_H
#endif
